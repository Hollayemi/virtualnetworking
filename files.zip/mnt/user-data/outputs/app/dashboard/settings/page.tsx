'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Space_Grotesk, Inter, IBM_Plex_Mono } from 'next/font/google';
import { Check, Building2, UserCircle, AlertTriangle } from 'lucide-react';
import { Pill } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { TextInput, PasswordInput } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { SectionCard } from '@/components/dashboard/ui';
import { useRole } from '@/lib/role-context';

/**
 * app/dashboard/settings/page.tsx
 * Account details, notification preferences, role management (this is
 * where the "switch on the other role later" promise from onboarding is
 * fulfilled), and account deletion.
 */

const display = Space_Grotesk({ subsets: ['latin'], weight: ['500', '600', '700'], variable: '--font-display' });
const body = Inter({ subsets: ['latin'], weight: ['400', '500', '600'], variable: '--font-body' });
const mono = IBM_Plex_Mono({ subsets: ['latin'], weight: ['400', '500'], variable: '--font-mono' });

type Notifications = {
  connectionRequests: boolean;
  messages: boolean;
  meetingReminders: boolean;
  marketingEmails: boolean;
};

export default function SettingsPage() {
  const { role, setRole } = useRole();
  const [name, setName] = useState('Amara Okafor');
  const [email, setEmail] = useState('amara@fieldstone.io');
  const [phone, setPhone] = useState('+1 (415) 555-0132');
  const [newPassword, setNewPassword] = useState('');
  const [saved, setSaved] = useState(false);

  const [notifications, setNotifications] = useState<Notifications>({
    connectionRequests: true,
    messages: true,
    meetingReminders: true,
    marketingEmails: false,
  });

  const [organiserEnabled, setOrganiserEnabled] = useState(false);
  const [enablingOrganiser, setEnablingOrganiser] = useState(false);
  const [orgName, setOrgName] = useState('');

  const toggleNotification = (key: keyof Notifications) => setNotifications((n) => ({ ...n, [key]: !n[key] }));

  const saveAccount = () => {
    // TODO: replace with your real account-update mutation
    setSaved(true);
    setTimeout(() => setSaved(false), 2400);
  };

  const enableOrganiser = () => {
    if (!orgName.trim()) return;
    // TODO: replace with your real "add organiser role" mutation
    setOrganiserEnabled(true);
    setEnablingOrganiser(false);
    setRole('organizer');
  };

  return (
    <div className={`${display.variable} ${body.variable} ${mono.variable} flex flex-col gap-6 text-[#EAF2ED]`} style={{ fontFamily: 'var(--font-body)' }}>
      <div>
        <h2 className="text-[1.5rem] font-semibold tracking-tight" style={{ fontFamily: 'var(--font-display)' }}>
          Settings
        </h2>
        <p className="mt-1 text-[13.5px] text-[#92A79C]">Manage your account, notifications, and roles.</p>
      </div>

      <SectionCard title="Account">
        <div className="flex flex-col gap-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <TextInput id="settings-name" label="Full name" value={name} onChange={(e) => setName(e.target.value)} />
            <TextInput id="settings-email" label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <TextInput id="settings-phone" label="Phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} optional />
          <PasswordInput
            id="settings-password"
            label="New password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            hint="Leave blank to keep your current password."
          />
          <div className="flex items-center gap-3">
            <Button onClick={saveAccount}>Save changes</Button>
            <AnimatePresence>
              {saved && (
                <motion.span
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0 }}
                  className="flex items-center gap-1.5 text-[13px] font-medium text-[#8FB8A4]"
                >
                  <Check className="h-4 w-4" />
                  Saved
                </motion.span>
              )}
            </AnimatePresence>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Notifications">
        <div className="flex flex-col divide-y divide-white/[0.06]">
          <NotificationRow
            label="Connection requests"
            hint="Someone sends you a request or accepts yours"
            checked={notifications.connectionRequests}
            onChange={() => toggleNotification('connectionRequests')}
          />
          <NotificationRow
            label="Messages"
            hint="New messages from your connections"
            checked={notifications.messages}
            onChange={() => toggleNotification('messages')}
          />
          <NotificationRow
            label="Meeting reminders"
            hint="15 minutes before a booked meeting"
            checked={notifications.meetingReminders}
            onChange={() => toggleNotification('meetingReminders')}
          />
          <NotificationRow
            label="Marketing emails"
            hint="Product updates and event recommendations"
            checked={notifications.marketingEmails}
            onChange={() => toggleNotification('marketingEmails')}
          />
        </div>
      </SectionCard>

      <SectionCard title="Roles">
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between gap-3 rounded-xl border border-white/[0.06] bg-white/[0.02] p-4">
            <div className="flex items-center gap-3">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#639781]/10 text-[#8FB8A4]">
                <UserCircle className="h-[18px] w-[18px]" />
              </span>
              <div>
                <p className="text-[13.5px] font-medium text-[#EAF2ED]">Attendee</p>
                <p className="text-[12px] text-[#7C8F85]">Active on every account by default</p>
              </div>
            </div>
            <Pill tone="sage">Enabled</Pill>
          </div>

          <div className="flex flex-col gap-3 rounded-xl border border-white/[0.06] bg-white/[0.02] p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#D9B26B]/10 text-[#D9B26B]">
                <Building2 className="h-[18px] w-[18px]" />
              </span>
              <div>
                <p className="text-[13.5px] font-medium text-[#EAF2ED]">Organiser</p>
                <p className="text-[12px] text-[#7C8F85]">Run events and manage attendees</p>
              </div>
            </div>
            {organiserEnabled ? (
              <Pill tone="gold">Enabled</Pill>
            ) : (
              <Button variant="secondary" onClick={() => setEnablingOrganiser((v) => !v)}>
                Enable organiser role
              </Button>
            )}
          </div>

          <AnimatePresence>
            {enablingOrganiser && !organiserEnabled && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <div className="rounded-xl border border-[#D9B26B]/20 bg-[#151009]/40 p-4">
                  <TextInput
                    id="org-name"
                    label="Organisation name"
                    value={orgName}
                    onChange={(e) => setOrgName(e.target.value)}
                    placeholder="Acme Conferences"
                  />
                  <Button accent="#D9B26B" className="mt-3 text-[#0A100D]" onClick={enableOrganiser}>
                    Confirm and switch to Organiser
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <p className="text-[12px] text-[#5F736A]">
            You're currently viewing the dashboard as <span className="text-[#8FB8A4]">{role === 'attendee' ? 'Attendee' : 'Organiser'}</span>. Switch anytime from the sidebar.
          </p>
        </div>
      </SectionCard>

      <SectionCard title="Danger zone">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#D9756B]/10 text-[#E0A093]">
              <AlertTriangle className="h-[18px] w-[18px]" />
            </span>
            <div>
              <p className="text-[13.5px] font-medium text-[#EAF2ED]">Delete account</p>
              <p className="text-[12px] text-[#7C8F85]">This permanently removes your profile, connections, and credit history.</p>
            </div>
          </div>
          <Button variant="danger">Delete account</Button>
        </div>
      </SectionCard>
    </div>
  );
}

function NotificationRow({ label, hint, checked, onChange }: { label: string; hint: string; checked: boolean; onChange: () => void }) {
  return (
    <div className="flex items-center justify-between gap-4 py-3.5 first:pt-0 last:pb-0">
      <div>
        <p className="text-[13.5px] font-medium text-[#EAF2ED]">{label}</p>
        <p className="text-[12px] text-[#7C8F85]">{hint}</p>
      </div>
      <Switch checked={checked} onChange={onChange} />
    </div>
  );
}

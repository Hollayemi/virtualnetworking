import type { ReactNode } from "react";
import Link from "next/link";
import { TrendingUp } from "lucide-react";

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-[#FAFAF8] flex flex-col">
      {/* Minimal nav */}
      <header className="w-full py-5 px-6 flex items-center justify-between border-b border-[#e8edf3] bg-white">
        <Link href="/" className="flex items-center gap-2.5 no-underline">
          <div className="w-8 h-8 rounded-lg bg-[#E8472F] flex items-center justify-center">
            <TrendingUp size={17} color="#fff" strokeWidth={2.2} />
          </div>
          <span
            className="font-semibold text-[17px] text-[#0D1B2A]"
            style={{ fontFamily: "var(--font-fraunces), serif" }}
          >
            VirtualNet
          </span>
        </Link>
        <p className="text-sm text-slate-400 hidden sm:block">
          Premium Event Networking
        </p>
      </header>

      <main className="flex-1 flex items-center justify-center px-4 py-12">
        {children}
      </main>

      <footer className="py-6 text-center text-xs text-slate-400 border-t border-[#e8edf3]">
        © {new Date().getFullYear()} VirtualNet Ltd · London, United Kingdom
      </footer>
    </div>
  );
}
